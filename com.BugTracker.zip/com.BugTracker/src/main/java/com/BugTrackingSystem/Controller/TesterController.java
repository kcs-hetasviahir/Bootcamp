package com.BugTrackingSystem.Controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.BugTrackingSystem.Entities.Project;
import com.BugTrackingSystem.Entities.Team;
import com.BugTrackingSystem.Entities.User;
import com.BugTrackingSystem.Service.ProjectService;
import com.BugTrackingSystem.Service.TeamService;
import com.BugTrackingSystem.Service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class TesterController {
	@Autowired
	private UserService userService;

	@Autowired
	private TeamService teamService;

	@Autowired
	private ProjectService projectService;

	/**
	 * 
	 * @param principal
	 * @param user
	 * @param model
	 * @return ViewTTeam {@summary Returns the page where Teams are listed of the
	 *         particular User}
	 */
	// View team of the Tester
	@GetMapping("/ViewTTeam")
	public String viewTesterTeam(Principal principal, User user, Model model) {
		user = userService.findByUsername(principal.getName());
		System.out.println(user.getId());
		model.addAttribute("team", teamService.findAllByUsers(user));
		return "ViewTTeam";
	}

	/**
	 * 
	 * @param id
	 * @param model
	 * @param project
	 * @return ViewTProject {@summary Returns a Page where Projects are listed on
	 *         which the logged in user is working}
	 */
	// View Project of the Tester
	@GetMapping("/viewTProjects/{id}")
	public String viewTesterProject(@PathVariable Long id, Model model, Project project) {
		Team team = teamService.getTeamById(id);
		List<Project> projectList = projectService.findAllByTeams(team);

		List<Project> projects = new ArrayList<>();
		Iterator<Project> itr = projectList.iterator();
		while (itr.hasNext()) {
			Project project2 = (Project) itr.next();
			if (project2.getStatus().contains("Completed")) {
				continue;
			} else {
				projects.add(project2);
			}
		}
		model.addAttribute("team", team);
		model.addAttribute("project", projects);
		return "ViewTProject";
	}

}
