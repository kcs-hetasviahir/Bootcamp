package com.BugTrackingSystem.Controller;

import java.security.Principal;

import com.BugTrackingSystem.Entities.Project;
import com.BugTrackingSystem.Entities.Team;
import com.BugTrackingSystem.Entities.User;
import com.BugTrackingSystem.Service.ProjectService;
import com.BugTrackingSystem.Service.TeamService;
import com.BugTrackingSystem.Service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class DeveloperController 
{
	@Autowired
	private UserService userService;

	@Autowired
	private TeamService teamService;

	@Autowired
	private ProjectService projectService;
	
	/**
	 * 
	 * @param principal
	 * @param user
	 * @param model
	 * @return ViewDTeam 
	 * {@summary Returns the list of Teams in which the user is listed}
	 */
	// View team of the Developer
		@GetMapping("/ViewDTeam")
		public String viewDeveloperTeam(Principal principal, User user, Model model) {
			user = userService.findByUsername(principal.getName());
			System.out.println(user.getId());
			model.addAttribute("team", teamService.findAllByUsers(user));
			return "ViewDTeam";
		}

		/**
		 * 
		 * @param id
		 * @param team
		 * @param model
		 * @return ViewDTeamMember
		 * {@summary Returns list of Members of the particular Team}
		 */
		// View TeamMates of developer 
		@GetMapping("/viewDTeamMember/{id}")
		public String viewDTeamMember(@PathVariable Long id, Team team, Model model) {
			model.addAttribute("team", teamService.getTeamById(id));
			model.addAttribute("user", userService.findAllByTeams(team));
			return "ViewDTeamMember";
		}
		
		/**
		 * 
		 * @param id
		 * @param model
		 * @param project
		 * @return ViewDProject 
		 * {@summary Returns list of Project }
		 */
		// View Project of the Developer
		@GetMapping("/viewDProjects/{id}")
		public String viewDeveloperProject(@PathVariable Long id, Model model,Project project) 
		{
			model.addAttribute("team",teamService.getTeamById(id));
			Team team = teamService.getTeamById(id);
			model.addAttribute("project",projectService.findAllByTeams(team));
			return "ViewDProject";
		}


}
