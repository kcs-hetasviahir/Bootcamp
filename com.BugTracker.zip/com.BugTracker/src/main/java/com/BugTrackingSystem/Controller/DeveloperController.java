package com.BugTrackingSystem.Controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.BugTrackingSystem.Entities.Bug;
import com.BugTrackingSystem.Entities.Project;
import com.BugTrackingSystem.Entities.Team;
import com.BugTrackingSystem.Entities.User;
import com.BugTrackingSystem.Service.BugService;
import com.BugTrackingSystem.Service.ProjectService;
import com.BugTrackingSystem.Service.TeamService;
import com.BugTrackingSystem.Service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DeveloperController 
{
	@Autowired
	private UserService userService;

	@Autowired
	private TeamService teamService;

	@Autowired
	private ProjectService projectService;
	
	@Autowired
	private BugService bugService;
	
	/**
	 * 
	 * @param principal
	 * @param user
	 * @param model
	 * @return ViewDTeam 
	 * {@summary Returns the list of Teams in which the user is listed}
	 */
	// View team of the Developer
		@GetMapping("/ViewDTeam")
		public String viewDeveloperTeam(Principal principal, User user, Model model) {
			user = userService.findByUsername(principal.getName());
			System.out.println(user.getId());
			model.addAttribute("team", teamService.findAllByUsers(user));
			return "ViewDTeam";
		}

		/**
		 * 
		 * @param id
		 * @param team
		 * @param model
		 * @return ViewDTeamMember
		 * {@summary Returns list of Members of the particular Team}
		 */
		// View TeamMates of developer 
		@GetMapping("/viewDTeamMember/{id}")
		public String viewDTeamMember(@PathVariable Long id, Team team, Model model) {
			model.addAttribute("team", teamService.getTeamById(id));
			model.addAttribute("user", userService.findAllByTeams(team));
			return "ViewDTeamMember";
		}
		
		/**
		 * 
		 * @param id
		 * @param model
		 * @param project
		 * @return ViewDProject 
		 * {@summary Returns list of Project }
		 */
		// View Project of the Developer
		@GetMapping("/viewDProjects/{id}")
		public String viewDeveloperProject(@PathVariable Long id, Model model,Project project) 
		{
			model.addAttribute("team",teamService.getTeamById(id));
			Team team = teamService.getTeamById(id);
			model.addAttribute("project",projectService.findAllByTeams(team));
			return "ViewDProject";
		}
		
		@RequestMapping("/viewDProjects/viewBug/{id}")
		public String showBug(Model model,Bug bug,Project project,@PathVariable Long id,User user,Principal principal)
		{
			user = userService.findByUsername(principal.getName());
			List<Bug> bugList = bugService.findAllByDeveloperId(user);
			List<Bug> bugs = new ArrayList<>();
			/* List<Bug> bugs2 = new ArrayList<>(); */
			
			Iterator<Bug> itr = bugList.iterator();
			while(itr.hasNext())
			{
				Bug bug2 = (Bug)itr.next();
				if(bug2.getStatus().contains("Completed"))
				{
					continue;
				}
				else
				{
					bugs.add(bug2);
				}
			}
			project =projectService.getProjectById(id);
			model.addAttribute("project",project);
			model.addAttribute("bug",bugs);
			
			return "ViewDBugs";
		}

		@GetMapping("/viewDProjects/viewBug/SolveBug/{id}")
		public  String solveBug(Model model,@PathVariable Long id)
		{	
			Bug bug = bugService.getBugById(id);
			bug.setStatus("Completed");
			
			bugService.saveBug(bug);
			return "redirect:/?viewDProjects/viewBug/{id}";
		}


}
