package com.BugTrackingSystem.Controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.BugTrackingSystem.Entities.Team;
import com.BugTrackingSystem.Entities.User;
import com.BugTrackingSystem.Entities.UserRole;
import com.BugTrackingSystem.Repository.UserRepository;
import com.BugTrackingSystem.Service.TeamService;
import com.BugTrackingSystem.Service.UserService;

@Controller

public class MainController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private TeamService teamService;

	// Home page
	@GetMapping("/")
	public String home(Principal principal, User user, Model model) {

		user = userService.findByUsername(principal.getName());
		String role = user.getRole().toString();

		if (role.contains("ROLE_ADMIN")) {

			System.out.println("Admin");
			return "Home";
		}

		if (role.contains("ROLE_TESTER")) {

			System.out.println("Tester");
			return "HomeTester";
		}
		if (role.contains("ROLE_DEVELOPER")) {

			System.out.println("Developer");
			return "HomeDeveloper";
		}

		return "redirect:/login";

	}

	// Login page
	@RequestMapping("/login")
	public String login() {

		return "login";
	}

	// Logout
	@RequestMapping("/logout-success")
	public String logout() {

		return "logout";
	}

	// Register User
	@GetMapping("/AddUser")
	public String register(Model model) {
		model.addAttribute("user", new User());
		return "AddUser";
	}

	@PostMapping("/AddUser")
	public String addUser(User user, @RequestParam("ROLES") Long role, UserRole userRole) {

		 userRole.setId(role);

		//userRole.setRole(userRole);
		System.out.println("started");
		user.setRole(userRole);

		userService.saveUser(user);

		return "redirect:/?success";
	}
	
	//View Users
	
	@GetMapping("/showuser")
	public String viewUsers(Model model) {
		model.addAttribute("user", userService.getAllUsers());

		return "ViewUser";
	}
	
	//Delete User

	@GetMapping("/user/delete/{id}")
	public String deleteUser(@PathVariable Long id, Principal principal) 
	{
		
		User user=userService.getUserById(id);
		List<Team> teams=teamService.findAllByUsers(user);
		
		for(int i=0;i<teams.size();i++)
		{
			Team team=teams.get(i);
			team.getUsers().remove(user);
			user.getTeams().remove(team);
			
			teamService.saveTeam(team);
			userService.saveUser(user);
		}
		userService.deleteUserById(user.getId());

		return "redirect:/showuser";

	}

	//Search User
	@GetMapping("/searchuser")
	public String searchUser(@RequestParam("firstname") String firstname, Model model) {

		model.addAttribute("user", userService.findByFirstname(firstname));

		return "ViewUser";
	}
	
	//Update User

	@GetMapping("/user/update/{id}")
	public String updateUser(@PathVariable Long id, Model model, Principal principal) {

		model.addAttribute("user", userService.getUserById(id));

		return "UpdateUser";
	}

	@PostMapping("/updateuser")

	public String updateUser(User user, @RequestParam("ROLES") Long role, UserRole userRole) {

		User existingUser = userService.getUserById(user.getId());

		existingUser.setId(user.getId());
		existingUser.setFirstname(user.getFirstname());
		existingUser.setLastname(user.getLastname());
		existingUser.setUsername(user.getUsername());

		//userRole.setRole(role);

		userRole.setId(role);
		user.setRole(userRole);

		existingUser.setRole(user.getRole());
		existingUser.setPassword(user.getPassword());

		userService.saveUser(existingUser);

		return "redirect:/?successupdate";
	}
	
	//Profile page
	@GetMapping("/profile")
	public String userProfile(Principal principal, Model model) {

		model.addAttribute("user", userService.findByUsername(principal.getName()));
		
		return "UpdateUser";
	}
	
	@GetMapping("/ViewDTeam")
	public String viewDeveloperTeam(Principal principal,User user,Model model)
	{
		user = userService.findByUsername(principal.getName());
		System.out.println(user.getId());
		model.addAttribute("team",teamService.findAllByUsers(user));
		return "ViewDTeam";
	}
	
	@GetMapping("/viewDTeamMember/{id}")
	public String viewDTeamMember(@PathVariable Long id,Team team,Model model)
	{
		model.addAttribute("team",teamService.getTeamById(id));
		model.addAttribute("user",userService.findAllByTeams(team));
		return "ViewDTeamMember";
	}

}
