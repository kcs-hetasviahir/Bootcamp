package com.BugTrackingSystem.Controller;

import com.BugTrackingSystem.Entities.Team;
import com.BugTrackingSystem.Entities.User;
import com.BugTrackingSystem.Entities.UserRole;
import com.BugTrackingSystem.Repository.TeamRepository;
import com.BugTrackingSystem.Service.TeamService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TeamController 
{
	@Autowired
	private TeamService teamService;
	
	/*
	 * @Autowired private TeamRepository teamRepository;
	 */
	// Register Team
		@GetMapping("/AddTeam")
		public String registerTeam(Model model) {
			model.addAttribute("team", new Team());
			return "AddTeam";
		}

		@PostMapping("/AddTeam")
		public String addTeam(Team team) {

			
			
			System.out.println("Started");
			 teamService.saveTeam(team);
			return "redirect:/?successTeam";
		}
		
		//View Team
		
		@GetMapping("/showTeam")
		public String viewTeams(Model model) {
			model.addAttribute("team", teamService.getAllTeams());
			return "ViewTeam";
		}

		@PostMapping("/addMember/{id}")
		public String addMember(Model model)
		{
			return "AddMember";
			
		}
}
