package com.BugTrackingSystem.Controller;

import java.util.List;

import com.BugTrackingSystem.Entities.Team;

import com.BugTrackingSystem.Entities.User;
import com.BugTrackingSystem.Entities.UserRole;
import com.BugTrackingSystem.Repository.TeamRepository;
import com.BugTrackingSystem.Service.TeamService;
import com.BugTrackingSystem.Service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TeamController {
	@Autowired
	private TeamService teamService;

	@Autowired
	private UserService userService;

	// Register Team
	@GetMapping("/AddTeam")
	public String registerTeam(Model model) {
		model.addAttribute("team", new Team());
		return "AddTeam";
	}

	@PostMapping("/AddTeam")
	public String addTeam(Team team) {

		System.out.println("Started");
		teamService.saveTeam(team);
		return "redirect:/?successTeam";
	}

	// View Team

	@GetMapping("/showTeam")
	public String viewTeams(Model model) {
		model.addAttribute("team", teamService.getAllTeams());
		return "ViewTeam";
	}
	
	/**
	 * 
	 * @param model
	 * @param id
	 * @param team
	 * @return AddMember
	 * {@summary Returns a page where we can add a Member to the Team}
	 */

	// Add Member View Page
	@GetMapping("/addMember/{id}")
	public String addMember(Model model, @PathVariable Long id, Team team) {
		team = teamService.getTeamById(id);
		List<User> users = userService.getAllUsers();
		List<User> teamUser = userService.findAllByTeams(team);

		for (int i = 0; i < teamUser.size(); i++) {
			User teamUser2 = teamUser.get(i);
			users.remove(teamUser2);
		}

		model.addAttribute("user", users);
		model.addAttribute("team", teamService.getTeamById(id));
		return "AddMember";

	}

	
	/**
	 * 
	 * @param id
	 * @param teamid
	 * @param model
	 * @param team
	 * @param user
	 * @return showTeam 
	 * 
	 * {@summary returns the page where Teams are listed}
	 */
	// Add Member in a Team
	@RequestMapping("/addMember/{id}/{teamid}")
	public String addTeamMember(@PathVariable("id") Long id, @PathVariable("teamid") Long teamid, Model model,
			Team team, User user) {
		team = teamService.getTeamById(teamid);
		user = userService.getUserById(id);

		team.getUsers().add(user);
		user.getTeams().add(team);

		teamService.saveTeam(team);
		userService.saveUser(user);
		return "redirect:/showTeam";
	}

	// View Team Member
	@GetMapping("/showTeamMember/{id}")
	public String viewTeamMember(Model model, @PathVariable Long id, Team team) {
		team = teamService.getTeamById(id);
		model.addAttribute("team", teamService.getTeamById(id));
		model.addAttribute("user", userService.findAllByTeams(team));
		return "ViewMember";
	}

	/**
	 * 
	 * @param id
	 * @param teamid
	 * @param team
	 * @param user
	 * 
	 * @see Team
	 * @see User {@summary Here is the code for Remove Team member from the Team}
	 *
	 * @return
	 */
	// View Team Member
	@RequestMapping("/showTeamMember/viewteam/user/remove/{id}/{teamid}")
	public String removeTeamMember(@PathVariable("id") Long id, @PathVariable("teamid") Long teamid, Team team,
			User user) {
		team = teamService.getTeamById(teamid);
		user = userService.getUserById(id);

		team.getUsers().remove(user);
		user.getTeams().remove(team);

		teamService.saveTeam(team);
		userService.saveUser(user);

		return "redirect:/showTeamMember/{teamid}";
	}

	// Delete Team

	@RequestMapping("/team/delete/{id}")
	public String deleteTeam(@PathVariable Long id) {
		teamService.deleteTeamById(id);
		return "redirect:/showTeam?delete";

	}
}
