package com.BugTrackingSystem.Controller;

import java.util.List;


import com.BugTrackingSystem.Entities.Project;
import com.BugTrackingSystem.Entities.Team;
import com.BugTrackingSystem.Service.ProjectService;
import com.BugTrackingSystem.Service.TeamService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ProjectController 
{
	@Autowired
	private ProjectService projectService;

	@Autowired
	private TeamService teamService;

	
	//Add Project Page
	@GetMapping("/AddProject")
	public String addProject(Model model) {
		model.addAttribute("project", new Project());
		return "AddProject";
	}

	//Add Project
	@PostMapping("/AddProject")
	public String registerProject(Project project) {
		project.setIsdeleted(false);
		projectService.saveProject(project);
		return "home";
	}
	//View Project
	@GetMapping("/showProject")
	public String showProject(Model model) {
		model.addAttribute("project", projectService.getAllProjects());
		return "ViewProject";
	}
	/**
	 * 
	 * @param model
	 * @param id
	 * @param project
	 * @param team
	 * @return AssignProject 
	 * {@summary Returns List of teams available for the assignment of the projects}
	 */
	//Assign Team to Project Page
	@GetMapping("/showProjects/{id}")
	public String assignTeamShow(Model model,@PathVariable Long id,Project project,Team team) 
	{
		project =projectService.getProjectById(id);
		
		List<Team> teams = teamService.getAllTeams();
		List<Team> teamProjects=teamService.findAllByProjects(project);
		
		for(int i=0;i<teamProjects.size();i++)
		{
			Team teamProjects2 = teamProjects.get(i);
			teams.remove(teamProjects2);
		}
		
		model.addAttribute("team",teams);
		model.addAttribute("project", projectService.getProjectById(id));
		return "AssignProject";
	}

	/**
	 * 
	 * @param id
	 * @param projectid
	 * @param project
	 * @param team
	 * @return successProject
	 * {@summary It returns to the home page after successfully assigning a team }
	 */
	//Assign Project
	@RequestMapping("/showProjects/showTeamMember/{id}/{projectid}")
	public String assignTeam(@PathVariable("id") Long id, @PathVariable("projectid") Long projectid, Project project,
			Team team) {

		team = teamService.getTeamById(id);
		project = projectService.getProjectById(projectid);
		
		project.getTeams().add(team);
		team.getProjects().add(project);
		
		projectService.saveProject(project);
		teamService.saveTeam(team);
		
		return "redirect:/?successProject";

	}
	
	/**
	 * 
	 * @param model
	 * @param id
	 * @param team
	 * @param project
	 * @return ViewTeamProject
	 * {@summary Returns a page Where you can see Teams in the particular Project}
	 */
	//View Assigned Team Page
	@GetMapping("/showAssignedTeam/{id}")
	public String viewAssignedTeam(Model model,@PathVariable Long id,Team team,Project project)
	{
		project =projectService.getProjectById(id);
		model.addAttribute("project",projectService.getProjectById(id));
		model.addAttribute("team",teamService.findAllByProjects(project));
		
		return "ViewTeamProject";
	}

	/**
	 * 
	 * @param id
	 * @param teamid
	 * @param team
	 * @param project
	 * @return showAssignedTeam 
	 * {@summary Returns list of teams after deleting}
	 */
	//Remove Assigned Team from the project  
	@GetMapping("/showAssignedTeam/viewproject/team/remove/{id}/{teamid}")
	public String removeAssignment(@PathVariable("id")Long id,@PathVariable("teamid")Long teamid,Team team,Project project)
	{
		project=projectService.getProjectById(id);
		team=teamService.getTeamById(teamid);
		
		project.getTeams().remove(team);
		team.getProjects().remove(project);
		
		projectService.saveProject(project);
		teamService.saveTeam(team);
		return "redirect:/showAssignedTeam/{id}";
	}
}
