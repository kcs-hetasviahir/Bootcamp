package com.BugTrackingSystem.Controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.BugTrackingSystem.Entities.Project;
import com.BugTrackingSystem.Entities.Team;
import com.BugTrackingSystem.Entities.User;
import com.BugTrackingSystem.Entities.UserRole;
import com.BugTrackingSystem.Service.ProjectService;
import com.BugTrackingSystem.Service.TeamService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ProjectController {
	@Autowired
	private ProjectService projectService;

	@Autowired
	private TeamService teamService;

	// Add Project Page
	@GetMapping("/AddProject")
	public String addProject(Model model) {
		model.addAttribute("project", new Project());
		return "AddProject";
	}

	/**
	 * 
	 * @param project
	 * @return successProjectAdd
	 * 
	 *         {@summary Returns success message after successful addition of
	 *         Project}
	 */
	// Add Project
	@PostMapping("/AddProject")
	public String registerProject(Project project) {
		project.setIsdeleted(false);
		projectService.saveProject(project);
		return "redirect:/?successProjectAdd";
	}

	// View Project
	@GetMapping("/showProject")
	public String showProject(Model model) {
		model.addAttribute("project", projectService.getAllProjects());
		return "ViewProject";
	}

	/**
	 * 
	 * @param model
	 * @param id
	 * @param project
	 * @param team
	 * 
	 * @see Project
	 * @see Team
	 * @return AssignProject {@summary Returns List of teams available for the
	 *         assignment of the projects}
	 */
	// Assign Team to Project Page
	@GetMapping("/showProjects/{id}")
	public String assignTeamShow(Model model, @PathVariable Long id, Project project, Team team) {
		List<Team> teams = teamService.getAllTeams();
		/*
		 * List<Team> teamProjects=teamService.findAllByProjectId(project.getId());
		 */

		List<Team> teamProjects = new ArrayList<Team>();

		

		teamProjects = teamService.findByProjectsNotIn(project.getId());
		System.out.println(project.getId());

		/*
		 * for(int i=0;i<teamProjects.size();i++) { Team teamProjects2 =
		 * teamProjects.get(i); teams.remove(teamProjects2); }
		 */

		model.addAttribute("team", teamProjects);
//		/model.addAttribute("project", project);
		return "AssignProject";
	}

	/**
	 * 
	 * @param id
	 * @param projectid
	 * @param project
	 * @param team
	 * @see Project
	 * @see Team
	 * @return successProject {@summary It returns to the home page after
	 *         successfully assigning a team }
	 */
	// Assign Project
	@RequestMapping("/showProjects/showTeamMember/{id}/{projectid}")
	public String assignTeam(@PathVariable("id") Long id, @PathVariable("projectid") Long projectid, Project project,
			Team team) {

		team = teamService.getTeamById(id);
		project = projectService.getProjectById(projectid);

		project.getTeams().add(team);
		team.getProjects().add(project);

		projectService.saveProject(project);
		teamService.saveTeam(team);

		return "redirect:/?successProject";

	}

	/**
	 * 
	 * @param model
	 * @param id
	 * @param team
	 * @param project
	 * @see Project
	 * @see Team
	 * @return ViewTeamProject {@summary Returns a page Where you can see Teams in
	 *         the particular Project}
	 */
	// View Assigned Team Page
	@GetMapping("/showAssignedTeam/{id}")
	public String viewAssignedTeam(Model model, @PathVariable Long id, Team team, Project project) {
		project = projectService.getProjectById(id);
		model.addAttribute("project", projectService.getProjectById(id));
		model.addAttribute("team", teamService.findAllByProjects(project));

		return "ViewTeamProject";
	}

	/**
	 * 
	 * @param id
	 * @param teamid
	 * @param team
	 * @param project
	 * @see Project
	 * @see Team
	 * @return showAssignedTeam {@summary Returns list of teams after deleting}
	 */
	// Remove Assigned Team from the project
	@GetMapping("/showAssignedTeam/viewproject/team/remove/{id}/{teamid}")
	public String removeAssignment(@PathVariable("id") Long id, @PathVariable("teamid") Long teamid, Team team,
			Project project) {
		project = projectService.getProjectById(id);
		team = teamService.getTeamById(teamid);

		project.getTeams().remove(team);
		team.getProjects().remove(project);

		projectService.saveProject(project);
		teamService.saveTeam(team);
		return "redirect:/showAssignedTeam/{id}?successUnassign";
	}

	@GetMapping("ModifyProject/{id}")
	public String modifyProject(@PathVariable Long id, Model model) {
		model.addAttribute("project", projectService.getProjectById(id));
		return "UpdateProject";
	}

	@PostMapping("/updateProject")
	public String updateUser(Project project) {

		Project pro1 = projectService.getProjectById(project.getId());
		pro1.setId(project.getId());
		pro1.setProject_name(project.getProject_name());
		pro1.setStatus(project.getStatus());
		pro1.setIsdeleted(false);
		pro1.setTechnology(project.getTechnology());

		projectService.saveProject(pro1);
		return "redirect:/showProject?successupdate";
	}

	/**
	 * 
	 * @param id
	 * @return showProject?delete
	 * 
	 *         {@summary Deletes a Project}
	 */
	// Delete Project
	@GetMapping("/DeleteProject/{id}")
	public String removeDelete(@PathVariable Long id) {
		projectService.deleteProjectById(id);
		return "redirect:/showProject?delete";
	}
}
