package com.BugTrackingSystem.Controller;

import java.security.Principal;

import com.BugTrackingSystem.Entities.Bug;
import com.BugTrackingSystem.Entities.Project;
import com.BugTrackingSystem.Entities.User;
import com.BugTrackingSystem.Service.BugService;
import com.BugTrackingSystem.Service.ProjectService;
import com.BugTrackingSystem.Service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BugController {
	@Autowired
	private BugService bugService;

	@Autowired
	private ProjectService projectService;

	@Autowired
	private UserService userService;

	// Register Bug
	@GetMapping("/viewTProjects/AddBug/{id}")
	public String addBug(Model model, Bug bug, @PathVariable Long id, Project project, Principal principal, User user) {
		project = projectService.getProjectById(id);
		/* team = teamService.getTeamById(teamid); */
		user = userService.findByUsername(principal.getName());
		bug.setProject_id(project);
		bug.setTester_id(user);
		/* bug.setTeams(team); */
		model.addAttribute("bug", bug);
		model.addAttribute("title", "Add Bug");
		return "AddBug";
	}

	@RequestMapping("/viewTProjects/AddBug/AddBug")
	public String registerBug(Bug bug) {
		bugService.saveBug(bug);
		return "HomeTester";
	}

	// View Bugs
	@GetMapping("/ViewBug")
	public String viewBug(Model model, Bug bug) /* ,Project project,@PathVariable Long id */
	{
		model.addAttribute("bug", bugService.getAllBugs());
		/* model.addAttribute("project",projectService.getProjectById(id)); */
		return "ViewBug";
	}

	/*
	 * @GetMapping("/AssignBug/{id}") public String AssignBug(Model model,Bug
	 * bug,@PathVariable Long id,Principal principal,Set<User> user,Set<Team> team)
	 * { Project project =projectService.getProjectById(id);
	 * team=teamService.findAllByProjects(project);
	 * 
	 * user=userService.findAllByTeamsList(team); System.out.println(project);
	 * System.out.println(team); System.out.println(user);
	 * model.addAttribute("user",user);
	 * model.addAttribute("bug",bugService.getAllBugs()); return "AssignBug"; }
	 */
}
