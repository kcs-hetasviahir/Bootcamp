package com.BugTrackingSystem.Controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.BugTrackingSystem.Entities.Bug;
import com.BugTrackingSystem.Entities.Project;
import com.BugTrackingSystem.Entities.Team;
import com.BugTrackingSystem.Entities.User;
import com.BugTrackingSystem.Entities.UserRole;
import com.BugTrackingSystem.Service.BugService;
import com.BugTrackingSystem.Service.ProjectService;
import com.BugTrackingSystem.Service.TeamService;
import com.BugTrackingSystem.Service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class BugController {
	@Autowired
	private BugService bugService;

	@Autowired
	private ProjectService projectService;

	@Autowired
	private UserService userService;

	@Autowired
	private TeamService teamService;

	// Register Bug
	@GetMapping("/viewTProjects/AddBug/{id}")
	public String addBug(Model model, Bug bug, @PathVariable Long id, Project project, Principal principal, User user) {
		project = projectService.getProjectById(id);
		user = userService.findByUsername(principal.getName());
		Set<User> user2 = new HashSet<>();

		List<Team> teams = teamService.findAllByProjects(project);
		for (Team team2 : teams) {
			Set<User> user1 = userService.findAllByTeams(team2);
			for (User user3 : user1) {
				String Role = "ROLE_DEVELOPER";
				UserRole userrole = user3.getRole();
				String roleuser = userrole.getRole();

				if (roleuser.equals(Role)) {
					user2.add(user3);
				}

			}

		}
		
		bug.setProjectId(project);
		bug.setTesterId(user);
		model.addAttribute("bug", bug);
		model.addAttribute("user", user2);
		model.addAttribute("title", "Add Bug");
		return "AddBug";
	}

	@PostMapping("/AddBug")
	public String saveBug(Bug bug,User user,Principal principal,@RequestParam("project")Long id,Project project) 
	{
		user = userService.findByUsername(principal.getName());
		project = projectService.getProjectById(id);
		
		bug.setProjectId(project);
		bug.setTesterId(user);
		User dev = bug.getDeveloperId();
		dev.getBugs().add(bug);
		bug.setDeveloperId(dev);
		bugService.saveBug(bug);
		userService.saveUser(user);

		return "redirect:/";
	}

	// View Bugs
	@GetMapping("/ViewBug")
	public String viewBug(Model model, Bug bug) /* ,Project project,@PathVariable Long id */
	{
		model.addAttribute("bug", bugService.getAllBugs());
		return "ViewBug";
	}
	
	@RequestMapping("/viewTProjects/ViewBug/{id}")
	public String showBug(Model model,Bug bug,Project project,@PathVariable Long id)
	{
		project =projectService.getProjectById(id);
		model.addAttribute("project",project);
		model.addAttribute("bug",bugService.findAllByProjectId(project));
		
		return "ViewPBugs";
	}
	

	

	
}
