package com.BugTrackingSystem.Controller;

import com.BugTrackingSystem.Entities.Project;

import com.BugTrackingSystem.Entities.Report;
import com.BugTrackingSystem.Service.ProjectService;
import com.BugTrackingSystem.Service.ReportService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ReportController {

	@Autowired
	private ProjectService projectService;

	@Autowired
	private ReportService reportService;

	@GetMapping("/GenerateReport/{id}")
	public String GenerateReport(Model model, @PathVariable Long id, Report report) {
		String currentDate = java.time.LocalDate.now().toString();
		String StartDate = java.time.LocalDate.now().minusDays(7).toString();

		Project project = projectService.getProjectById(id);

		report.setPid(project);
		report.setProjectName(project.getProject_name());
		report.setStart_date(StartDate);
		report.setEnd_date(currentDate);
		report.setStatus(project.getStatus());
		report.setTechnology(project.getTechnology());

		model.addAttribute("project", report);

		return "Report";

	}

	@PostMapping("/AddReport")
	public String RegisterReport(Model model, Report report, Project project) {
		project = report.getPid();
		reportService.saveReport(report);
		return "redirect:/?ReportAdd";
	}

}
