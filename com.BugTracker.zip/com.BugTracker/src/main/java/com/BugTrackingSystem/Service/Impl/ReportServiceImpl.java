package com.BugTrackingSystem.Service.Impl;

import java.util.List;

import com.BugTrackingSystem.Entities.Report;
import com.BugTrackingSystem.Repository.ReportRepository;
import com.BugTrackingSystem.Service.ReportService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ReportServiceImpl implements ReportService {

	@Autowired
	private ReportRepository reportRepository;

	@Override
	public Report saveReport(Report report) {

		return reportRepository.save(report);
	}

	@Override
	public List<Report> getAllReports() {

		return reportRepository.findAll();
	}

}
