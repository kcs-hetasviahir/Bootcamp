package com.BugTrackingSystem.Service.Impl;

import java.util.List;

import com.BugTrackingSystem.Entities.Team;
import com.BugTrackingSystem.Repository.TeamRepository;
import com.BugTrackingSystem.Service.TeamService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TeamServiceImpl implements TeamService {

	@Autowired
	private TeamRepository teamRepository;

	@Override
	public Team saveTeam(Team team) {

		return teamRepository.save(team);
	}

	@Override
	public List<Team> getAllTeams() {

		return teamRepository.findAll();
	}

	@Override
	public Team getTeamById(Long id) {
		return teamRepository.findById(id).get();
	}

	@Override
	public void deleteTeamById(Long id) {
		teamRepository.deleteById(id);
	}

}
