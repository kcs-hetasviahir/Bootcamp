package com.BugTrackingSystem.Service.Impl;

import java.util.List;

import com.BugTrackingSystem.Entities.Project;
import com.BugTrackingSystem.Entities.Team;
import com.BugTrackingSystem.Entities.User;
import com.BugTrackingSystem.Repository.TeamRepository;
import com.BugTrackingSystem.Service.TeamService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TeamServiceImpl implements TeamService {

	@Autowired
	private TeamRepository teamRepository;

	@Override
	public Team saveTeam(Team team) {

		return teamRepository.save(team);
	}

	@Override
	public List<Team> getAllTeams() {

		return teamRepository.findAll();
	}

	@Override
	public Team getTeamById(Long id) {
		return teamRepository.findById(id).get();
	}

	@Override
	public void deleteTeamById(Long id) {
		teamRepository.deleteById(id);
	}

	@Override
	public List<Team> getAllMembers(Long id) {

		return teamRepository.findAllById(id);
	}

	@Override
	public List<Team> findAllByUsers(User user) {

		return teamRepository.findAllByUsers(user);
	}

	@Override
	public List<Team> findAllByProjects(Project project) {

		return teamRepository.findAllByProjects(project);
	}

	@Override
	public List<Team> findAllByProjectId(Long id) {

		return teamRepository.findAllByProjectId(id);
	}

	@Override
	public List<Team> findByProjectsNotIn(Long id) {
		// TODO Auto-generated method stub
		return teamRepository.findByProjectsNotIn(id);
	}


}
