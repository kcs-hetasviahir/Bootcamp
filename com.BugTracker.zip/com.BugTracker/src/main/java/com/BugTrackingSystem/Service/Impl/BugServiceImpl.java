package com.BugTrackingSystem.Service.Impl;

import java.util.List;

import com.BugTrackingSystem.Entities.Bug;
import com.BugTrackingSystem.Entities.Project;
import com.BugTrackingSystem.Repository.BugRepository;
import com.BugTrackingSystem.Service.BugService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BugServiceImpl implements BugService {

	@Autowired
	private BugRepository bugRepository;

	@Override
	public Bug saveBug(Bug bug) {

		return bugRepository.save(bug);
	}

	@Override
	public List<Bug> getAllBugs() {

		return bugRepository.findAll();
	}

	@Override
	public Bug getBugById(Long id) {

		return bugRepository.findById(id).get();
	}

	@Override
	public void deletBugById(Long id) {

		bugRepository.deleteById(id);
	}

	@Override
	public List<Bug> findAllByProjectId(Project project) {
		
		return bugRepository.findAllByProjectId(project);
	}

}
