package com.BugTrackingSystem.Service;

import java.util.List;

import com.BugTrackingSystem.Entities.Team;

public interface TeamService {

	Team saveTeam(Team team);

	List<Team> getAllTeams();

	Team getTeamById(Long id);

	void deleteTeamById(Long id);

}
