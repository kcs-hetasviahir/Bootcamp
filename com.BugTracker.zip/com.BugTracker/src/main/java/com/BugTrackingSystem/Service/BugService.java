package com.BugTrackingSystem.Service;

import java.util.List;


import com.BugTrackingSystem.Entities.Bug;
import com.BugTrackingSystem.Entities.Project;


public interface BugService {

	Bug saveBug(Bug bug);

	List<Bug> getAllBugs();

	Bug getBugById(Long id);

	void deletBugById(Long id);
	
	List<Bug> findAllByProjectId(Project project);

}
