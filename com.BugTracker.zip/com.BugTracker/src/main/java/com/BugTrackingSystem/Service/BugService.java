package com.BugTrackingSystem.Service;

import java.util.List;


import com.BugTrackingSystem.Entities.Bug;
import com.BugTrackingSystem.Entities.Project;
import com.BugTrackingSystem.Entities.User;


public interface BugService {

	Bug saveBug(Bug bug);

	List<Bug> getAllBugs();

	Bug getBugById(Long id);

	void deletBugById(Long id);
	
	List<Bug> findAllByProjectId(Project project);

	List<Bug> findAllByDeveloperId(User user);
}
