package com.BugTrackingSystem.Service;

import java.util.List;

import com.BugTrackingSystem.Entities.Report;

public interface ReportService {

	Report saveReport(Report report);

	List<Report> getAllReports();

}
