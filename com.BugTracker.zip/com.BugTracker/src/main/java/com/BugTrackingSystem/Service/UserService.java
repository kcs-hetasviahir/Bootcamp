package com.BugTrackingSystem.Service;


import java.util.List;

import com.BugTrackingSystem.Entities.Team;
import com.BugTrackingSystem.Entities.User;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserService  extends UserDetailsService{

	
	User saveUser(User user);
	
	User findByUsername(String username);
	
	List<User> getAllUsers();
	
	User getUserById(Long id);
	
	void deleteUserById(Long id);
	
	List<User> findByFirstname(String firstname);
	
	User getTeamById(Long id);

	Object findAllByTeams(Team team);
	
}
