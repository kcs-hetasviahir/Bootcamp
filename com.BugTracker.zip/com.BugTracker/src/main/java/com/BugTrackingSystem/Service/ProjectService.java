package com.BugTrackingSystem.Service;

import java.util.List;

import com.BugTrackingSystem.Entities.Project;

public interface ProjectService 
{
	Project saveProject(Project project);
	
	List<Project> getAllProjects();
	
	Project getProjectById(Long id);
	
	void deleteProjectById(Long id);
	
}
