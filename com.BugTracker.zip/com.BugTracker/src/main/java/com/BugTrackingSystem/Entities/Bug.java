package com.BugTrackingSystem.Entities;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.ManyToOne;

import javax.persistence.OneToOne;

/*Entity for Bug table*/
@Entity
public class Bug {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(unique = true)
	private String bug_desc;
	
	@Column(unique = true)
	private String status;

	@OneToOne
	private User tester_id;
	
	@OneToOne
	private Project project_id;
	
	@ManyToOne
	private Team teams;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getBug_desc() {
		return bug_desc;
	}

	public void setBug_desc(String bug_desc) {
		this.bug_desc = bug_desc;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public User getTester_id() {
		return tester_id;
	}

	public void setTester_id(User tester_id) {
		this.tester_id = tester_id;
	}

	public Project getProject_id() {
		return project_id;
	}

	public void setProject_id(Project project_id) {
		this.project_id = project_id;
	}

	public Team getTeams() {
		return teams;
	}

	public void setTeams(Team teams) {
		this.teams = teams;
	}

	public Bug(Long id, String bug_desc, String status, User tester_id, Project project_id, Team teams) {
		super();
		this.id = id;
		this.bug_desc = bug_desc;
		this.status = status;
		this.tester_id = tester_id;
		this.project_id = project_id;
		this.teams = teams;
	}

	public Bug() {
		super();
	}

	@Override
	public String toString() {
		return "Bug [id=" + id + ", bug_desc=" + bug_desc + ", status=" + status + ", tester_id=" + tester_id
				+ ", project_id=" + project_id + ", teams=" + teams + "]";
	}

	
		
}
