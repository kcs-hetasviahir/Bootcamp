package com.BugTrackingSystem.Entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.ManyToOne;

import javax.persistence.OneToOne;

/*Entity for Bug table*/
@Entity
public class Bug {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(unique = true)
	private String bug_desc;

	private String status;

	@OneToOne
	private User testerId;

	@OneToOne
	private Project projectId;

	@ManyToOne
	private User developerId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getBug_desc() {
		return bug_desc;
	}

	public void setBug_desc(String bug_desc) {
		this.bug_desc = bug_desc;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public User getTesterId() {
		return testerId;
	}

	public void setTesterId(User testerId) {
		this.testerId = testerId;
	}

	public Project getProjectId() {
		return projectId;
	}

	public void setProjectId(Project projectId) {
		this.projectId = projectId;
	}

	public User getDeveloperId() {
		return developerId;
	}

	public void setDeveloperId(User developerId) {
		this.developerId = developerId;
	}

	public Bug(Long id, String bug_desc, String status, User testerId, Project projectId, User developerId) {
		super();
		this.id = id;
		this.bug_desc = bug_desc;
		this.status = status;
		this.testerId = testerId;
		this.projectId = projectId;
		this.developerId = developerId;
	}

	public Bug() {
		super();
	}

	@Override
	public String toString() {
		return "Bug [id=" + id + ", bug_desc=" + bug_desc + ", status=" + status + ", testerId=" + testerId
				+ ", projectId=" + projectId + ", developerId=" + developerId + "]";
	}

}
