package com.BugTrackingSystem.Repository;

import java.util.List;

import com.BugTrackingSystem.Entities.Bug;
import com.BugTrackingSystem.Entities.Project;
import com.BugTrackingSystem.Entities.User;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BugRepository extends JpaRepository<Bug, Long> 
{
	List<Bug> findAllByProjectId(Project project);
	
	List<Bug> findAllByDeveloperId(User user);

}
