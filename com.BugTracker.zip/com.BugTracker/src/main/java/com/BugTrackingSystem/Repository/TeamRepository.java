package com.BugTrackingSystem.Repository;

import java.util.List;

import com.BugTrackingSystem.Entities.Project;
import com.BugTrackingSystem.Entities.Team;
import com.BugTrackingSystem.Entities.User;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface TeamRepository extends JpaRepository<Team, Long> {

	List<Team> findAllById(Long id);

	List<Team> findAllByUsers(User user);

	List<Team> findAllByProjects(Project project);

	@Query(value = "select team.* from team\r\n"
			+ "left outer join project_teams project_teams1 on team.id = project_teams1.teams_id\r\n"
			+ "left outer join project  project1 on project_teams1.projects_id=project1.id\r\n"
			+ "where project1.id='id'", nativeQuery = true)

	List<Team> findAllByProjectId(Long id);

	
	
	@Query(value="select * \r\n"
			+ "from team\r\n"
			+ "where id \r\n"
			+ "not in (select distinct pt.teams_id \r\n"
			+ "from project_teams pt where pt.projects_id = ?1)",nativeQuery = true)
	List<Team> findAllByProjectsNot(Long id);
	
	

	List<Team> findAllByProjectsNotIn(List<Long>Id);



}
